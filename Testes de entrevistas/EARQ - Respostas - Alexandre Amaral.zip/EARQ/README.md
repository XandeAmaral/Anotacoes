Exercícios de Alexandre de Carvalho Amaral para a entrevista da EARQ.

### Como executar

Como não tinha especificação de qual linguagem usar optei por utilizar o javascript.

Então para executar os exercícios basta copiar o código, abrir o devtools de um navegador, colar o código no console e executar.

Qualquer dúvida estou à disposição e agradeço mais uma vez pela oportunidade.